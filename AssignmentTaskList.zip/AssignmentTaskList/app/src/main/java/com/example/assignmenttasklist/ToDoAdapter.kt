package com.example.assignmenttasklist

import android.content.Context
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text

class ToDoAdapter(private var data: List<Data>, context: Context): RecyclerView.Adapter<ToDoAdapter.TaskViewHolder>() {


    private val db: AssignmentDataHelper = AssignmentDataHelper(context)
     private  var taskId : Int = -1


    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {


        val viewTitleText: TextView = itemView.findViewById(R.id.titleView)
        val viewContentText: TextView = itemView.findViewById(R.id.contentHolderView)
        val viewStatusText: TextView = itemView.findViewById(R.id.statusText)
        val deleteButton: ImageView = itemView.findViewById(R.id.deleteButton)
        val doneSwitch: Switch = itemView.findViewById(R.id.switch1)

    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
       val view = LayoutInflater.from(parent.context).inflate(R.layout.todo_item, parent, false)
        return TaskViewHolder(view)


    }


    override fun getItemCount(): Int = data.size



    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val data = data[position]
        holder.viewTitleText.text = data.title
        holder.viewStatusText.text = data.status
        holder.viewContentText.text = data.content



        holder.doneSwitch.setOnClickListener{
            var title = holder.viewTitleText.text.toString()
            var content = holder.viewContentText.toString()

            if(holder.viewStatusText.text == "Complete"){
                holder.viewStatusText.setTextColor(Color.parseColor("#FF3D02"))
              val  done= holder.viewStatusText.setText ("Not Complete").toString()

                var completeTask = Data(position, title, content, done)
                db.completeTask(completeTask)

            }else{
                holder.viewStatusText.setTextColor(Color.parseColor("#02FF24"))

                val  done= holder.viewStatusText.setText("Complete").toString()

                   var  completeTask = Data(position, title, content, done)
                db.completeTask(completeTask)
                Toast.makeText(holder.itemView.context,"Task Completed",Toast.LENGTH_LONG).show()
            }



        } // end onClick Listener

        holder.deleteButton.setOnClickListener{
           db.delelteTask(data.id)
            refreshData(db.getAllAssignmentTask())
            Toast.makeText(holder.itemView.context, "To do item has been removed", Toast.LENGTH_SHORT).show()
        }

    }


    fun refreshData(newTask: List<Data>) {
        data = newTask
        notifyDataSetChanged()
    }
}