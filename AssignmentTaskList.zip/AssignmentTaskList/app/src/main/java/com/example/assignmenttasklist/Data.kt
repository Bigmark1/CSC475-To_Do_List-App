package com.example.assignmenttasklist

data class Data(val id: Int, val title: String, val content: String, val status: String)
