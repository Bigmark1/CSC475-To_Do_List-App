package com.example.assignmenttasklist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.assignmenttasklist.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: AssignmentDataHelper
    private lateinit var todoAdapter: ToDoAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AssignmentDataHelper(this)

        todoAdapter = ToDoAdapter(db.getAllAssignmentTask(),this)
        binding.todoRecycleView.layoutManager = LinearLayoutManager(this)
        binding.todoRecycleView.adapter = todoAdapter

        binding.floatingActionButton.setOnClickListener{
            val intent = Intent(this, InputTaskActivity::class.java)
            startActivity(intent)
        }



    }
    override fun onResume() {
        super.onResume()
        todoAdapter.refreshData(db.getAllAssignmentTask())
    }




}