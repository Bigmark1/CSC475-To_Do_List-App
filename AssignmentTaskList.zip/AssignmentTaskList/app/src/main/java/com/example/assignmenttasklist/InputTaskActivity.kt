package com.example.assignmenttasklist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.assignmenttasklist.databinding.ActivityInputTaskBinding

class InputTaskActivity : AppCompatActivity() {
   private lateinit var binding: ActivityInputTaskBinding
   private lateinit var db: AssignmentDataHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityInputTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AssignmentDataHelper(this)

        binding.donebuttons.setOnClickListener{ // mark

            var notDone: TextView = findViewById<TextView?>(R.id.addstatusText)
            notDone.setText("Not Complete")
           val title = binding.editInputText.text.toString()
          val content =  binding.contentEdit.text.toString()
           val status = binding.addstatusText.text.toString()

            val data = Data(0,title, content, status)
            db.insertTask(data)
            finish()
            Toast.makeText(this,"Added to List",Toast.LENGTH_SHORT).show()


        }



    }





}